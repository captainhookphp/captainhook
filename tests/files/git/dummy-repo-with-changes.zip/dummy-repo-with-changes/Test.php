<?php

/**
 * Super PHPDoc comment
 */
class DummyCode
{
    const FOO = 'bar';
}
