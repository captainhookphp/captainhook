<?php

class DummyCode
{
    const FOO = 'bar';
}
